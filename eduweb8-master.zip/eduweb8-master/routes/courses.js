module.exports={
    design:function(){
        return ["fusion 360","iphone","myphone","iphone4","iphone5"]
    },
    filmmaking:function(){ return 0;

    },
    development:function(){ return 0;

    },
    itandsoftware:function(){ return 0;

    },
    personaldevelopment:function(){ return 0;

    },
    technology:function(){ return 0;

    },
    marketing:function(){ return 0;

    },
    business:function(){ return 0;

    }
    
}